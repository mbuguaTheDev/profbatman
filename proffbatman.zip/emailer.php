<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//autoload from composer
//require 'vendor/autoload.php' ;
require 'src/PHPMailer.php';

$mail = new PHPMailer(TRUE);

// Open the try/catch block
try {
   //sender
   $mail->setFrom('lmbugua45@gmail.com', 'Lawrence');
   
   $mail-> isHTML(TRUE);

   //recipient
   $mail->addAddress('opencubetechnologies@gmail.com');

   //subject
   $mail->Subject = 'New Order';

   //email body
   $mail->Body = "Hi, this is just a test message";

   // Send the mail.
   $mail->send();
}
catch (Exception $e)
{
   
   echo $e->errorMessage();
}
catch (\Exception $e)
{
   echo $e->getMessage();
}
?>